#include "Parser.h"

void Parser::parseFile(const std::string fileName, std::vector<City*> &vec){
    //you write
    
}